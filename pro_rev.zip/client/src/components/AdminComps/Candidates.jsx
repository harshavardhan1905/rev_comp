import React, { useEffect } from 'react';
import axios from 'axios';
import AddComp from '../AdminComps/addCandidate';

export default function Candidates() {

    const [candidates, setCandidates] = React.useState([]);
    const [selectedCandidate, setSelectedCandidate] = React.useState(null);
    const [view, setView] = React.useState(null);
    const [showModal, setShowModal] = React.useState(false);

    const [filterStatus, setFilterStatus] = React.useState("all");

    useEffect(() => {
        axios.get('http://localhost:5000/api/candidates')
            .then(response => {
                setCandidates(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the candidates!', error);
            });
    }, []);

    // FORMAT DATE
    const formatDate = (dateString) => {
        if (!dateString) return "—";
        const date = new Date(dateString);
        const day = date.getDate().toString().padStart(2, "0");
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    };

    // FILTER LOGIC
    const filteredCandidates = candidates.filter((c) => {
        if (filterStatus === "all") return true;
        return c.final_status === filterStatus;
    });

    return (
        <div>
            <div className="justify-content-center align-items-center min-vh-100 w-100 m-0" style={{ overflowY: "hidden" }}>

                {/* TOP BAR */}
                <div className="d-flex justify-content-between align-items-center">
                    <h3>Companies</h3>

                    <div className='d-flex' id='tops'>

                        {/* STATUS FILTER */}
                        <div>
                            {/* <label className='form-label form-lable-status'>Status:</label> */}
                            <select
                                id="status"
                                className="form-control"
                                value={filterStatus}
                                onChange={(e) => setFilterStatus(e.target.value)}
                            >
                                <option value="all">All</option>
                                <option value="PENDING">Pending</option>
                                <option value="COMPLETED">Completed</option>
                            </select>
                        </div>

                        {/* ADD COMPANY BUTTON */}
                        <div className="ms-2">
                            <button
                                className="btn btn-success"
                                onClick={() => {
                                    setView("addcomp");
                                    setShowModal(true);
                                }}
                            >
                                Add Comp
                            </button>
                        </div>
                    </div>
                </div>

                {/* TABLE */}
                <div className="table-wrapper mt-4"
                    style={{ maxHeight: "580px", overflowY: "auto", overflowX: "hidden" }}>

                    <table className="table table-bordered table-hover">
                        <thead className="table-dark" style={{ position: "sticky", top: 0, zIndex: 10 }}>
                            <tr>
                                <th style={{ width: '10px' }}>Id</th>
                                <th>Company Domain</th>
                                <th>Company Name</th>
                                <th>Website</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Registered Date</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>
                            {filteredCandidates.map((candidate) => (
                                <tr key={candidate.candidate_id}
                                style={{
                                    backgroundColor:
                                        candidate.final_status === "COMPLETED" ? "#c8f7c5" : "transparent"
                                    }}
                                >
                                    <td className='td-wrap'>{candidate.candidate_id}</td>
                                    <td className='td-wrap'>{candidate.comp_domain}</td>
                                    <td className='td-wrap'>{candidate.comp_name}</td>

                                    <td className='td-wrap'>
                                        <a href={`https://${candidate.website}`} target="_blank" rel="noreferrer">
                                            {candidate.website}
                                        </a>
                                    </td>

                                    <td className='td-wrap'>{candidate.email}</td>
                                    <td className='td-wrap'>{candidate.phone}</td>
                                    <td className='td-wrap'>{formatDate(candidate.date_of_register)}</td>

                                    <td className='td-wrap'>
                                        <button
                                            style={{
                                                background: "linear-gradient(90deg,#2575fc,#6a11cb)",
                                                border: "none",
                                                borderRadius: "6px",
                                                fontWeight: "400",
                                                color: "#fff",
                                                padding: "4px 10px"
                                            }}
                                            onClick={() => {
                                                setSelectedCandidate(candidate);
                                                setShowModal(true);
                                                setView("followups");
                                            }}
                                        >
                                            Follow-Ups
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>


                {/* FOLLOW-UPS MODAL */}
                {view === "followups" && showModal && selectedCandidate && (
                    <div className="modal fade show"
                        style={{ display: "block", background: "rgba(0,0,0,0.5)", margin:"0px" }}>

                        <div className="modal-dialog" style={{ maxWidth: "auto", width: "auto" }}>

                            <div className="model-content-sec">

                                <div className="modal-header">
                                    <h5 className="modal-title">
                                        {selectedCandidate.email} - Details
                                    </h5>

                                    <button className="btn-close" onClick={() => setShowModal(false)}></button>
                                </div>

                                <div className="modal-body">
                                    <table className="table table-bordered" style={{ minWidth: "auto" }}>
                                        <tbody>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>First Follow-up Date</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{formatDate(selectedCandidate.first_f_date)}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>First Follow-up Status</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.first_f_status}</td>
                                            </tr>

                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Second Follow-up Date</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}> {formatDate(selectedCandidate.second_f_date)}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Second Follow-up Status</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.second_f_status}</td>
                                            </tr>

                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Third Follow-up Date</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{formatDate(selectedCandidate.third_f_date)}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Third Follow-up Status</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.third_f_status}</td>
                                            </tr>

                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Fourth Follow-up Date</th>
                                                <td>{formatDate(selectedCandidate.fourth_f_date)}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Fourth Follow-up Status</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.fourth_f_status}</td>
                                            </tr>

                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Final Status</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.final_status}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Assigned Employee</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.emp_name}</td>
                                            </tr>
                                            <tr>
                                                <th style={{ width: "250px", whiteSpace: "nowrap" }}>Country</th>
                                                <td style={{ width: "250px", whiteSpace: "nowrap" }}>{selectedCandidate.country_name}</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>

                                <div className="modal-footer">
                                    <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Close</button>
                                </div>

                            </div>
                        </div>
                    </div>
                )}



                {/* ADD COMPANY MODAL */}
                {view === "addcomp" && showModal && (
                    <div className="modal fade show"
                        style={{ display: "block", background: "rgba(0,0,0,0.5)" }}>

                        <div className="modal-dialog" style={{ maxWidth: "auto", width: "auto" }}>
                            <div className="model-content-sec" style={{ position: "relative" }}>

                                <div className="d-flex justify-content-between align-items-center"
                                    style={{ padding: "10px 20px" }}>

                                    <h4 className="m-0">Add New Company</h4>

                                    <button className="btn-close" onClick={() => setShowModal(false)}></button>
                                </div>

                                <AddComp />
                            </div>
                        </div>

                    </div>
                )}

            </div>
        </div>
    );
}
